<?php


class registeration 
{
   private $verificationCode;
   



public function setVerificationCode($verificationCode)
{
    $this->verificationCode=$verificationCode;
}


public function getVerificationCode()
{
return $this->verificationCode;
}

}

?>